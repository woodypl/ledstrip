/* Copyright (C) 2012 mbed.org, MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include "mbed.h"
#include "rtos.h"
#include "Wifly.h"
#include <string>
#include <algorithm>
#include <ctype.h>

// Defined to disable remote configuration via telnet which increases security of this device,
// for Wifly module SW 2.27 and higher.
#define INCREASE_SECURITY

//#define DEBUG       //Debug is disabled by default

#if (defined(DEBUG) && !defined(TARGET_LPC11U24))
#define DBG(x, ...)  std::printf("[DBG Wifly%3d] "x"\r\n", __LINE__, ##__VA_ARGS__);
#define WARN(x, ...) std::printf("[WRN Wifly%3d] "x"\r\n", __LINE__, ##__VA_ARGS__);
#define ERR(x, ...)  std::printf("[ERR Wifly%3d] "x"\r\n", __LINE__, ##__VA_ARGS__);
#define INFO(x, ...) std::printf("[INF Wifly%3d] "x"\r\n", __LINE__, ##__VA_ARGS__);
#else
#define DBG(x, ...)
#define WARN(x, ...)
#define ERR(x, ...)
#define INFO(x, ...)
#endif

#define MAX_TRY_JOIN 3

Wifly * Wifly::inst;
Mutex wifly_mutex;

Wifly::Wifly(   PinName tx, PinName rx, PinName _reset, PinName tcp_status, const char * ssid, const char * phrase, Security sec):
    wifi(tx, rx), reset_pin(_reset), tcp_status(tcp_status), baudrate(9600), buf_wifly(256)
{
    memset(&state, 0, sizeof(state));
    state.sec = sec;

    FixPhrase(&this->ssid, ssid);
    FixPhrase(&this->phrase, phrase);

    inst = this;
    attach_rx(false);
    setCmdMode(false);
    wiflyVersionString = NULL;
}

Wifly::~Wifly()
{
    if (ssid) {
        free(ssid);
        ssid = NULL;
    }
    if (phrase) {
        free(phrase);
        phrase = NULL;
    }
    if (wiflyVersionString) {
        free(wiflyVersionString);
        wiflyVersionString = NULL;
    }
}

void Wifly::SetSecurity(const char * ssid, const char * phrase, Security sec)
{
    state.sec = sec;
    free(&this->ssid);          // release the old versions
    free(&this->phrase);
    FixPhrase(&this->ssid, ssid);
    FixPhrase(&this->phrase, phrase);
}

bool Wifly::join()
{
    char cmd[20];

    INFO("join");
    for (int i= 0; i < MAX_TRY_JOIN; i++) {

        // auto-join - or it won't reconnect upon failure (!@#$!#)
        if (!sendCommand("set w j 1\r", "AOK"))
            continue;

        // no echo
        if (!sendCommand("set u m 1\r", "AOK"))
            continue;

        // set comm time to flush (ms)
        if (!sendCommand("set c t 30\r", "AOK"))
            continue;

        // set comm size to auto-send
        if (!sendCommand("set c s 1420\r", "AOK"))
            continue;

        // set comm idle time to auto-close (sec)
        //if (!sendCommand("set c i 5\r", "AOK"))
        //    continue;

        // red led on when tcp connection active
        if (!sendCommand("set s i 0x40\r", "AOK"))
            continue;

        // no hello string sent to the tcp client
        if (!sendCommand("set c r 0\r", "AOK"))
            continue;

        // tcp protocol
        if (!sendCommand("set i p 2\r", "AOK"))
            continue;

        // tcp retry (retry enabled, Nagle alg, retain link)
        if (!sendCommand("set i f 0x7\r", "AOK"))
            continue;

#ifdef INCREASE_SECURITY
        // tcp-mode 0x10 = disable remote configuration
        // only in SW 2.27 and higher (see 2.3.39)
        if ((swVersion >= 2.27) && (!sendCommand("set i t 0x10\r", "AOK")))
            continue;
#endif

        // set dns server
        if (!sendCommand("set d n rn.microchip.com\r", "AOK"))
            continue;

        //dhcp
        sprintf(cmd, "set i d %d\r", (state.dhcp) ? 1 : 0);
        if (!sendCommand(cmd, "AOK"))
            continue;

        // ssid
        sprintf(cmd, "set w s %s\r", ssid);
        if (!sendCommand(cmd, "AOK"))
            continue;

        //auth
        sprintf(cmd, "set w a %d\r", state.sec);
        if (!sendCommand(cmd, "AOK"))
            continue;

        // if no dhcp, set ip, netmask and gateway
        if (!state.dhcp) {
            DBG("not dhcp");

            sprintf(cmd, "set i a %s\r\n", ip);
            if (!sendCommand(cmd, "AOK"))
                continue;

            sprintf(cmd, "set i n %s\r", netmask);
            if (!sendCommand(cmd, "AOK"))
                continue;

            sprintf(cmd, "set i g %s\r", gateway);
            if (!sendCommand(cmd, "AOK"))
                continue;
        }

        //key step
        cmd[0] = '\0';
        switch (state.sec) {
            case WPE_64:        // google searching suggests this is a typo and should be WEP_64
            case WEP_128:
                sprintf(cmd, "set w k %s\r", phrase);
                break;
            case WPA1:
            case WPA_MIXED: // alias WPA
            case WPA2_PSK:
                sprintf(cmd, "set w p %s\r", phrase);
                break;
            case ADHOC:
            case NONE:
            default:
                break;
        }
        if (cmd[0] && !sendCommand(cmd, "AOK"))
            continue;

        //join the network (10s timeout)
        if (state.dhcp) {
            if (!sendCommand("join\r", "DHCP=ON", NULL, 10000))
                continue;
        } else {
            if (!sendCommand("join\r", "Associated", NULL, 10000))
                continue;
        }

        if (!sendCommand("save\r", "Stor"))
            continue;

        exit();

        state.associated = true;
        // Don't advertise this info
        //INFO("\r\nssid: %s\r\nphrase: %s\r\nsecurity: %s\r\n\r\n", this->ssid, this->phrase, getStringSecurity());
        return true;
    }
    return false;
}


bool Wifly::setProtocol(Protocol p)
{
    // use udp auto pairing
    char cmd[20];
    sprintf(cmd, "set i p %d\r", p);
    if (!sendCommand(cmd, "AOK"))
        return false;

    switch(p) {
        case TCP:
            // set ip flags: tcp retry enabled
            if (!sendCommand("set i f 0x07\r", "AOK"))
                return false;
            break;
        case UDP:
            // set ip flags: udp auto pairing enabled
            if (!sendCommand("set i h 0.0.0.0\r", "AOK"))
                return false;
            if (!sendCommand("set i f 0x40\r", "AOK"))
                return false;
            break;
    }
    state.proto = p;
    return true;
}


char * Wifly::getStringSecurity()
{
    switch(state.sec) {
        case NONE:              // 0
            return "NONE";
        case WEP_128:           // 1
            return "WEP_128";
        case WPA1:              // 2
            return "WPA1";
        case WPA:               // 3
            return "WPA";
        case WPA2_PSK:          // 4
            return "WPA2_PSK";
        case ADHOC:             // 6
            return "ADHOC";
        case WPE_64:            // 8
            return "WPE_64";
        default:                // ?
            return "UNKNOWN";
    }
}


bool Wifly::connect(const char * host, int port)
{
    char rcv[20];
    char cmd[20];

    // try to open
    sprintf(cmd, "open %s %d\r", host, port);
    if (sendCommand(cmd, "OPEN", NULL, 10000)) {
        state.tcp = true;
        exit();
        return true;
    }

    // if failed, retry and parse the response
    if (sendCommand(cmd, NULL, rcv, 5000)) {
        if (strstr(rcv, "OPEN") == NULL) {
            if (strstr(rcv, "Connected") != NULL) {
                if (!sendCommand("close\r", "CLOS"))
                    return false;
                if (!sendCommand(cmd, "OPEN", NULL, 10000))
                    return false;
            } else {
                return false;
            }
        }
    } else {
        return false;
    }

    state.tcp = true;
    exit();
    return true;
}


bool Wifly::gethostbyname(const char * host, char * ip)
{
    string h = host;
    char cmd[30], rcv[100];
    int l = 0;
    char * point;
    int nb_digits = 0;

    // no dns needed
    int pos = h.find(".");
    if (pos != string::npos) {
        string sub = h.substr(0, h.find("."));
        nb_digits = atoi(sub.c_str());
    }
    //printf("substrL %s\r\n", sub.c_str());
    if (count(h.begin(), h.end(), '.') == 3 && nb_digits > 0) {
        strcpy(ip, host);
    }
    // dns needed
    else {
        nb_digits = 0;
        sprintf(cmd, "lookup %s\r", host);
        if (!sendCommand(cmd, NULL, rcv))
            return false;

        // look for the ip address
        char * begin = strstr(rcv, "=") + 1;
        for (int i = 0; i < 3; i++) {
            point = strstr(begin + l, ".");
            INFO("str: %s", begin + l);
            l += point - (begin + l) + 1;
        }
        INFO("str: %s", begin + l);
        while(*(begin + l + nb_digits) >= '0' && *(begin + l + nb_digits) <= '9') {
            INFO("digit: %c", *(begin + l + nb_digits));
            nb_digits++;
        }
        memcpy(ip, begin, l + nb_digits);
        ip[l+nb_digits] = 0;
        INFO("ip from dns: %s", ip);
    }
    return true;
}


void Wifly::flush()
{
#if 0 and defined(DEBUG)
    char chatter[500];
    int count = 0;
    char c;

    while (buf_wifly.available()) {
        buf_wifly.dequeue(&c);
        chatter[count++] = c;
    }
    chatter[count] = '\0';
    if (count)
        DBG("Wifly::flush {%s}", chatter);
#endif
    buf_wifly.flush();
}


bool Wifly::sendCommand(const char * cmd, const char * ack, char * res, int timeout)
{
    int tries = 1;

    INFO("sendCommand %s", cmd);
    while (tries <= 2) {
        if (cmdMode()) {      // some influences to the wifi module sometimes kick it out
            if (send(cmd, strlen(cmd), ack, res, timeout) >= 0) {
                return true;
            }
        }
        setCmdMode(false);     // must not really be in cmd mode
        ERR("sendCommand: failure %d when sending: %s", tries, cmd);
        tries++;
    }
    return false;
}


bool Wifly::cmdMode()
{
    // if already in cmd mode, return
    if (state.cmd_mode) {
        // Quick verify to ensure we really are in cmd mode
        flushIn(0);
        //INFO("  send \\r to test for cmdMode");
        if (send("\r", 1, ">") == 1) {
            //INFO("  is cmdMode");
            return true;
        } else {
            INFO(" failed to detect command mode");
            setCmdMode(false);
        }
    }
    wait_ms(260);   // manual 1.2.1 (250 msec before and after)
    if (send("$$$", 3, "CMD") == -1) {  // the module controls the 'after' delay
        ERR("cannot enter in cmd mode");
        return false;
    }
    setCmdMode(true);
    return true;
}


bool Wifly::disconnect()
{
    // if already disconnected, return
    if (!state.associated)
        return true;

    if (!sendCommand("leave\r", "DeAuth"))
        return false;
    exit();

    state.associated = false;
    return true;
}


bool Wifly::is_connected()
{
    return (tcp_status.read() ==  1) ? true : false;
}


void Wifly::reset()
{
    reset_pin = 0;
    wifi.baud(9600);
    wait_ms(400);
    reset_pin = 1;
    GatherLogonInfo();
}


bool Wifly::reboot()
{
    if (sendCommand("reboot\r", "Reboot")) {
        setCmdMode(false);
        //INFO("  cmdMode = false");
        wait_ms(500);
        wifi.baud(9600);
        baud(baudrate);
        exit();
        return true;
    } else {
        return false;
    }
}


bool Wifly::close()
{
    if (!state.tcp) {
        return true;    // already closed
    }
    if (!sendCommand("close\r", "*CLOS*")) {
        return false;   // failed to close
    }
#if 1
    // It appears that the close exits cmd mode
    // so we won't bother trying to close which
    // could cause it to open command mode to
    // send the close (which add more 0.5s delays).
    setCmdMode(false);
#else
    flushIn();
    exit();
#endif
    state.tcp = false;
    return true;        // succeeded to close
}


int Wifly::putc(char c)
{
    while (!wifi.writeable())
        ;
    return wifi.putc(c);
}


bool Wifly::exit()
{
    if (!sendCommand("exit\r", "EXIT")) {
        ERR("  failed to exit.");
        return false;
    }
    setCmdMode(false);
    return true;
}


int Wifly::readable()
{
    return buf_wifly.available();
}


int Wifly::writeable()
{
    return wifi.writeable();
}


char Wifly::getc()
{
    char c = 0;
    while (!buf_wifly.available())
        ;
    buf_wifly.dequeue(&c);
    return c;
}


void Wifly::handler_rx(void)
{
    //read characters
    while (wifi.readable())
        buf_wifly.queue(wifi.getc());
}


void Wifly::attach_rx(bool callback)
{
    if (!callback)
        wifi.attach(NULL);
    else
        wifi.attach(this, &Wifly::handler_rx);
}


int Wifly::send(const char * str, int len, const char * ACK, char * res, int timeout)
{
    char read;
    int ackIndex = 0;
    Timer tmr;
    int result = 0;

    wifly_mutex.lock();
    attach_rx(false);
    tmr.start();
    //INFO("send(%s) at %d", str, tmr.read_ms());
    for (int i = 0; i < len; i++)
        result = (putc(str[i]) == str[i]) ? result + 1 : result;    // count successful sends
    if (!ACK || !strcmp(ACK, "NO")) {
        ;
    } else {
        while (1) {
            if (tmr.read_ms() > timeout) {
                flushIn();
                WARN("Timeout at %d ms seeking [%s] from [\r\n%s\r\n]", tmr.read_ms(), ACK, str);
                attach_rx(true);
                return -1;
            } else if (wifi.readable()) {
                read = wifi.getc();
                //INFO("  getc %2X  %d", read, tmr.read_ms());
                if (tolower(read) != tolower(ACK[ackIndex]))
                    ackIndex = 0;
                if (tolower(read) == tolower(ACK[ackIndex])) {
                    ackIndex++;
                    if (ackIndex == strlen(ACK))
                        break;
                }
            } else {
                ; // INFO("  waiting %d", tmr.read_ms());
            }
        }
        //INFO(" found %s.", ACK);
        attach_rx(true);
        wifly_mutex.unlock();
        return result;
    }

    //the user wants the result from the command (ACK == NULL, res != NULL)
    if ( res != NULL) {
        int i = 0;
        while (1) {
            if (tmr.read_ms() > timeout) {
                res[i] = '\0';
                if (i == 0) {
                    res = NULL;
                }
                //INFO("timeout awaiting response to %s", str);
                //wait_ms(100);
                break;
            } else {
                if (wifi.readable()) {
                    read = wifi.getc();
                    // we drop \r and \n, but should we since it is for user code...
                    //if ( read != '\r' && read != '\n') {
                    res[i++] = read;
                    //}
                }
            }
        }
    }
    flushIn();
    attach_rx(true);
    wifly_mutex.unlock();
    return result;
}


void Wifly::flushIn(int timeout_ms)
{
    Timer tmr;
#if 0 and defined(DEBUG)
    char chatter[500];
    int count = 0;
    int c;
#endif

    if (timeout_ms <= 0) {
        timeout_ms = 1; // 2 * 10000 / baudrate;  // compute minimal timeout
    }
    tmr.start();
    while (wifi.readable() || (tmr.read_ms() < timeout_ms)) {
        if (wifi.readable()) {
#if 0 and defined(DEBUG)
            c = wifi.getc();
            if (count < sizeof(chatter)-1)  // guard overflow
                chatter[count++] = c;
#else
            wifi.getc();
#endif
            tmr.reset();
            tmr.start(); // start should not be necessary
        }
    }
#if 0 and defined(DEBUG)
    chatter[count] = '\0';
    if (count)
        INFO("Wifly::flushIn(%d) {%s}", count, chatter);
#endif
}


// The ARM uart and the Wifly uart have to be in sync or we get
// no meaningful response, so then have to try the possibilities.
//
// First try is at the currently configured ARM uart baud, if
// that fails then it shifts the ARM uart baud through the probable
// speeds, trying to establish contact with the Wifly module.
// Once contact is demonstrated (by response to the 'ver' command),
// then it sets the Wifly module and then the ARM uart.
bool Wifly::baud(int _targetBaud)
{
    // in testing, 460800 and 921600 may change the Wifly module where you can't
    // change it back w/o a reset. So, we won't even permit those speeds.
    const int baudrates[] = {2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400}; //, 460800, 921600};
#define BRCOUNT (sizeof(baudrates)/sizeof(baudrates[0]))
    char cmd[26];       // sized for "set u i 460800\r" [15+1], plus margin [4]
    int tryIndex = 0;
    bool res = false;
    int userIndex;

    sprintf(cmd, "set uart instant %d\r", _targetBaud);
    // set u i # should cause it to exit command mode (manual 2.3.64),
    // but testing indicates that it does not.
    for (userIndex=0; userIndex < BRCOUNT; userIndex++) {
        if (_targetBaud == baudrates[userIndex]) {
            while (tryIndex <= BRCOUNT) {
                //INFO("baud() try: %d: %d", tryIndex, _targetBaud);
                sendCommand(cmd); // shift Wifly to desired speed [it may not respond (see 2.3.64)]
                flushIn(10);
                //setCmdMode(false);  // see note above why this is disabled
                wifi.baud(_targetBaud);     // shift the ARM uart to match
                if (sendCommand("ver\r", "wifly", NULL, 125)) {  // use this to verify communications
                    baudrate = _targetBaud;
                    res = true;
                    break;              // success
                }
                // keep trying baudrates between ARM and WiFly
                if (tryIndex < BRCOUNT) {
                    //INFO(" baud() set to %d", baudrates[tryIndex]);
                    wifi.baud(baudrates[tryIndex]);
                }
                tryIndex++;
            }
            break;  // if they selected a legitimate baud, try no others
        }
    }
    //INFO(" baud() result: %d", res);
    return res;
}


int Wifly::timeToRespond(int stringLen)
{
    return 150 + (1 | 10000/baudrate) * stringLen;
}


void Wifly::FixPhrase(char ** dst, const char * src)
{
    *dst = (char *)malloc(strlen(src)+1);
    if (*dst) {
        strcpy(*dst, src);
        // change all ' ' to '$' in ssid or passphrase
        for (int i = 0; i < strlen(*dst); i++) {
            if ((*dst)[i] == ' ')
                (*dst)[i] = '$';
        }
    } else {
        *dst = NULL;
    }
}


void Wifly::GatherLogonInfo()
{
    Timer timer;
    char logonText[200];
    int i = 0;
    char *p;

    timer.start();
    if (wiflyVersionString) {
        free(wiflyVersionString);
        wiflyVersionString = NULL;
    }
    logonText[i] = '\0';
    while (timer.read_ms() < 500) {
        while (wifi.readable() && (i <sizeof(logonText)-1)) {
            logonText[i++] = wifi.getc();
        }
    }
    logonText[i] = '\0';
    p = strchr(logonText, '\r');
    if (p)
        *p = '\0';
    wiflyVersionString = (char *)malloc(strlen(logonText)+1);
    if (wiflyVersionString) {
        strcpy(wiflyVersionString, logonText);
    }
    p = strstr(logonText, "Ver ");          // "Ver 4.00" for ver <= 4.00
    if (!p) p = strstr(logonText, "Ver: "); // "Ver: 4.40" new in ver 4.40
    if (p) {
        while (*p && (*p < '0' || *p > '9'))
            p++;
        swVersion = atof(p);
    }
    INFO("swVersion: %3.2f,\r\nverString: {%s}", swVersion, wiflyVersionString);
}


float Wifly::getWiflyVersion()
{
    return swVersion;
}


char * Wifly::getWiflyVersionString()
{
    return wiflyVersionString;
}


void Wifly::setConnectionState(bool value)
{
    state.tcp = value;
}

void Wifly::setCmdMode(bool newState)
{
    state.cmd_mode = newState;
}

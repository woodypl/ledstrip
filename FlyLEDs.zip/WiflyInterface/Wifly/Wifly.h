/* Copyright (C) 2012 mbed.org, MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * @section DESCRIPTION
 *
 * Wifly RN131-C, wifi module
 *
 * Datasheet:
 *
 * http://dlnmh9ip6v2uc.cloudfront.net/datasheets/Wireless/WiFi/WiFly-RN-UM.pdf
 */

#ifndef WIFLY_H
#define WIFLY_H

#include "mbed.h"
#include "RawSerial.h"
#include "CBuffer.h"

#define DEFAULT_WAIT_RESP_TIMEOUT 1000

enum Security {     // See Wifly user manual Table 2-13.
    NONE        = 0,
    WEP_128     = 1,
    WPA1        = 2,
    WPA_MIXED   = 3,
    WPA         = 3,  // maintained for backward compatibility
    WPA2_PSK    = 4,
    ADHOC       = 6,
    WPE_64      = 8,
    WEP_64      = 8   // probably what the last one should have been
};

enum Protocol {
    UDP = (1 << 0),
    TCP = (1 << 1)
};

/** the Wifly object
*
* This object controls the Wifly module.
*/
class Wifly
{

public:
    /**
    * Constructor
    *
    * @param tx mbed pin to use for tx line of Serial interface
    * @param rx mbed pin to use for rx line of Serial interface
    * @param reset reset pin of the wifi module ()
    * @param tcp_status connection status pin of the wifi module (GPIO 6)
    * @param ssid ssid of the network
    * @param phrase WEP or WPA key
    * @param sec Security type (NONE, WEP_128, WPA1, WPA | WPA_MIXED, WPA2_PSK, WEP_64 )
    */
    Wifly(PinName tx, PinName rx, PinName reset, PinName tcp_status, const char * ssid, const char * phrase, Security sec);

    /**
    * Destructor to clean up
    */
    ~Wifly();
    
    /** Optional means to set/reset the security
    *
    * If join() has not been called, then you can revise the security parameters
    * from those in the constructor.
    *
    * @param ssid ssid of the network
    * @param phrase WEP or WPA key
    * @param sec Security type (NONE, WEP_128, WPA1, WPA | WPA_MIXED, WPA2_PSK, WEP_64 )
    */
    void SetSecurity(const char * ssid, const char * phrase, Security sec);

    /**
    * Connect the wifi module to the ssid contained in the constructor.
    *
    * @return true if connected, false otherwise
    */
    bool join();

    /**
    * Disconnect the wifly module from the access point
    *
    * @return true if successful
    */
    bool disconnect();

    /**
    * Open a tcp connection with the specified host on the specified port
    *
    * @param host host (can be either an ip address or a name. If a name is provided, a dns request will be established)
    * @param port port
    * @return true if successful
    */
    bool connect(const char * host, int port);


    /**
    * Set the protocol (UDP or TCP)
    *
    * @param p protocol
    * @return true if successful
    */
    bool setProtocol(Protocol p);

    /**
    * Reset the wifi module
    */
    void reset();
    
    /**
    * Reboot the wifi module
    *
    * @return true if it could send the command, false otherwise
    */
    bool reboot();

    /**
    * Check if characters are available
    *
    * @return number of available characters
    */
    int readable();

    /**
    * Check if characters are available
    *
    * @return number of available characters
    */
    int writeable();

    /**
    * Check if a tcp link is active
    *
    * @return true if successful
    */
    bool is_connected();

    /**
    * Read a character
    *
    * @return the character read
    */
    char getc();

    /**
    * Flush the buffer
    */
    void flush();

    /**
    * Write a character
    *
    * @param the character which will be written
    * @return the character written
    */
    int putc(char c);


    /**
    * To enter in command mode (we can configure the module)
    *
    * @return true if successful, false otherwise
    */
    bool cmdMode();

    /**
    * To exit the command mode
    *
    * @return true if successful, false otherwise
    */
    bool exit();

    /**
    * Close a tcp connection, and exit command mode.
    *
    * @return true if successful
    */
    bool close();

    /**
    * Send a string to the wifi module by serial port. This function desactivates the user interrupt handler when a character is received to analyze the response from the wifi module.
    * Useful to send a command to the module and wait a response.
    *
    *
    * @param str string to be sent
    * @param len string length
    * @param ACK string which must be acknowledge by the wifi module. If ACK == NULL, no string has to be acknoledged. (default: "NO")
    * @param res this field will contain the response from the wifi module, result of a command sent. This field is available only if ACK = "NO" AND res != NULL (default: NULL)
    * @param timeout is the time in msec to wait for the acknowledge
    *
    * @return true if ACK has been found in the response from the wifi module. False otherwise or if there is no response in 5s.
    */
    int send(const char * str, int len, const char * ACK = NULL, char * res = NULL, int timeout = DEFAULT_WAIT_RESP_TIMEOUT);

    /**
    * Send a command to the wify module. Check if the module is in command mode. If not enter in command mode
    *
    * @param str string to be sent
    * @param ACK string which must be acknowledge by the wifi module. If ACK == NULL, no string has to be acknoledged. (default: "NO")
    * @param res this field will contain the response from the wifi module, result of a command sent. This field is available only if ACK = "NO" AND res != NULL (default: NULL)
    * @param timeout is the time in msec to wait for the acknowledge
    *
    * @return true if successful
    */
    bool sendCommand(const char * cmd, const char * ack = NULL, char * res = NULL, int timeout = DEFAULT_WAIT_RESP_TIMEOUT);
    
    /**
    * Return true if the module is using dhcp
    *
    * @return true if the module is using dhcp
    */
    bool isDHCP() {
        return state.dhcp;
    }

    /**
    * gets the host ip address
    *
    * @param host is a pointer to the host string to look up
    * @param ip contains the host IP in a string after the lookup.
    * @param sizeof_ip is the size of the buffer pointed to by ip
    * @return true if successful
    */
    bool gethostbyname(const char * host, char * ip);

    /**
    * Set the baud rate between the ARM and the WiFly.
    *
    * This will set the WiFly module baud rate first and then
    * set the ARM interface to match it. If it cannot get the proper 
    * acknowledge response, it will go on a hunt through the range 
    * of standard baud rates.
    *
    * @note Baud rate must be one of 2400, 4800, 9600, 19200, 38400, 57600,
    *       115200, 230400, 460800, or 921600. (See Wifly manual 2.3.64)
    * @note Baud rate of 230400 has been seen to be marginal w/o flow control.
    * @note Setting a baud rate to a 460800 or above may be unrecoverable
    *       without resetting the Wifly module.
    *
    * @param baudrate is the desired baudrate.
    *
    * @return true if it succeeded, which means that communications can continue, 
    * @return false if it failed to establish a communication link.
    */
    bool baud(int baudrate);


    /**
    * Sets the connection state. 
    *
    * Typically used by external apps that detect an incoming connection.
    *
    * @param state sets the connection state to true or false
    */
    void setConnectionState(bool state);


    /**
    * Get the version information from the Wifly module.
    *
    * @return the version information as a string, or NULL
    */
    char * getWiflyVersionString();
    
    
    /**
    * Get the software version from the Wifly module.
    *
    * This extracts the basic version number (e.g. 2.38, 4.00)
    * as a float.
    *
    * @return the software version number as a float.
    */
    float getWiflyVersion();


    /**
    * determine if the module is in command mode
    *
    * @return true if in command mode, false otherwise
    */
    bool isCmdMode() {
        return state.cmd_mode;
    }


    static Wifly * getInstance() {
        return inst;
    };

protected:
    #ifdef MODSERIAL_H
    MODSERIAL wifi;
    #else
    RawSerial wifi;
    #endif
    DigitalOut reset_pin;
    DigitalIn tcp_status;
    int baudrate;
    char * phrase;
    char * ssid;
    char * wiflyVersionString;
    float swVersion;
    const char * ip;
    const char * netmask;
    const char * gateway;
    CircBuffer<char> buf_wifly;

    static Wifly * inst;

    void attach_rx(bool null);
    void handler_rx(void);
    void flushIn(int timeout_ms = -1);

    typedef struct STATE {
        bool associated;
        bool tcp;
        bool dhcp;
        Security sec;
        Protocol proto;
        bool cmd_mode;
    } State;

    State state;
    char * getStringSecurity();
    
    void setCmdMode(bool newState);
    
    /**
    * Estimates the time needed for the Wifly module to respond
    * to some of the simple commands.
    *
    * This should only be used for simple commands, where the module should
    * be able to respond almost immediately.
    *
    * @param stringLen of the command to be sent, in characters.
    *
    * @return integer number of milliseconds (always rounded up a little)
    */
    int timeToRespond(int stringLen);

    /**
    * Allocate space for the parameter (ssid or passphrase)
    * and then fix it (change ' ' to '$').
    *
    * @param dst is a reference to the private member pointer.
    * @src is a pointer to a passed in string.
    */
    void FixPhrase(char ** dst, const char * src);

    /**
    * Gather the Wifly module version information for later queries
    */
    void GatherLogonInfo();

};

#endif
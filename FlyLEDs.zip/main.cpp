#include "rtos.h"
#include "mbed.h"
#include "LPD8806.h"
#include "WiflyInterface.h"
#include "HTTPClient.h"
#include <cstring>

const unsigned int ledcount1 = 8, ledcount2 = 2;
const unsigned int CMDLEN = 7, THREADMAX = 10;
const char* essid = "G162 Private";
const char* psk = "R069ibt83Q";
//const char* essid = "dcsf102";
//const char* psk = "Lilybank gdns";
const char* masterhost = "10.10.10.28";
//const char* masterhost = "192.168.200.105";
const int masterport = 8000;
const char* url = "http://10.10.10.28:8000/registerstrip";
//const char* url = "http://192.168.200.105:8000/registerstrip";

LPD8806 strip = LPD8806(ledcount1,0);
LPD8806 strip2 = LPD8806(ledcount2,1);
WiflyInterface wifly(p28, p27, p26, p25, essid, psk, WPA2_PSK);
HTTPClient http;
//Serial pc = Serial(p9,p10);
Serial pc = Serial(USBTX, USBRX);
TCPSocketConnection client;
Thread* threadlist[10];
//unsigned int threadcnt = THREADMAX;
Mutex tmmutex;

bool breathes[ledcount1];

void breathe(int pos)
{
    const int BREATHE_PERIOD = 4500;    // ms
    const int INHALE_PERIOD = (BREATHE_PERIOD / 4);
    const int EXHALE_PERIOD = (BREATHE_PERIOD / 2);
    const int HOLD_PERIOD = (BREATHE_PERIOD / 8);
    float brightness;

    uint8_t color[3];
    strip.getPixelColor(pos, color);

    while(breathes[pos]) {
        for (int i = 0; i <= 32; i++) {
            brightness = i * i / (float)(32 * 32);
            strip.setPixelColor(pos, strip.Color((uint8_t)(color[0]*brightness),(uint8_t)(color[1]*brightness),(uint8_t)(color[2]*brightness)));
            strip.show();
            Thread::wait(INHALE_PERIOD / 32);
        }

        Thread::wait(HOLD_PERIOD);

        for (int i = 0; i <= 32; i++) {
            brightness = 1- (i * i / (float)(32 * 32));
            strip.setPixelColor(pos, strip.Color((uint8_t)(color[0]*brightness),(uint8_t)(color[1]*brightness),(uint8_t)(color[2]*brightness)));
            strip.show();
            Thread::wait(EXHALE_PERIOD / 32);
        }
        Thread::wait(HOLD_PERIOD);
    }
}


void handle_command(void const* buf)
{
    const char * cmd = (const char*) buf;
    unsigned lednum = 0;
    LPD8806* actstrip;

    //pc.printf("Cmd: %s\r\n", cmd);


    if (cmd[1] == '0') /* Choose the right strip */
        actstrip = &strip;
    else
        actstrip = &strip2;

    switch (cmd[0]) {
        case '!': {
            actstrip->show();
            //client.send_all("Turning off LED\r\n", 17);
            break;
        }
        case '=': {
            lednum = 10*(cmd[2]-'0')+cmd[3]-'0';
            actstrip->setPixelColor(lednum, actstrip->Color(cmd[4], cmd[5], cmd[6]));
            //pc.printf("Handling LED %u: %2x, %2x, %2x\r\n", lednum, cmd[4], cmd[5], cmd[6]);
            //client.send_all("Turning on LED\r\n", 16);
            break;
        }
        case '>': {
            lednum = 10*(cmd[2]-'0')+cmd[3]-'0';
            breathes[lednum] = !breathes[lednum];
            breathe(lednum);
            break;
        }
        default: {
            client.send_all("Unknown command\r\n", 17);
        }
    }
    delete [] buf;

}

void listen(void const* arg)
{
    //char cmdbuf[1024]= { '\0' };
    char buffer[1024];
    char cmd;
    //Thread* t = NULL;

    while (true) {
        //read 1 character and look for the start of command (255)
        if (client.receive(&cmd, 1) <= 0 || cmd != '\xff')
            continue;

        //pc.printf("Start of command detected.\r\n");
        //OK, we're in a command

        int n = 0;
        while (n < CMDLEN)
            n += client.receive(buffer+n, sizeof(buffer-n));

        //pc.printf("Received full command: %s. Handling.\r\n", buffer);
        //t = new Thread(handle_command, (void*) buffer);
        //ffs. memory mgmt
        void * bufptr = new char[CMDLEN];
        memcpy(bufptr, buffer, CMDLEN);
        tmmutex.lock();
        unsigned int i = 0;
        while (threadlist[i] != NULL && threadlist[i]->get_state() != Thread::Inactive) {
            i++;
            if (i == THREADMAX)
                i = 0; //loop until we have space
        }
        delete threadlist[i];
        threadlist[i] = new Thread(handle_command, bufptr);
        tmmutex.unlock();
        //handle_command((void*) bufptr);

    }
}

int main()
{
    pc.baud(9600);
    //pc.attach(&serialRecv);
    pc.printf("uC alive!\r\n");
    wifly.init(); // use DHCP
    float v = wifly.getWiflyVersion();
    pc.printf("Version %f. Trying to connect...", v);
    while (!wifly.connect()); // join the network
    //wifly.connect();

    /* There is a broadcast anyway... This is an early attempt to register via HTTP
    pc.printf("IP Address is %s\r\n", wifly.getIPAddress());
    pc.printf("Connected! Notifying master at %s:%d...\r\n", masterhost, masterport);
    char str[128];
    http.get(url, str, 128, 2000);
    */

    // Start up the LED strip
    strip.begin();
    strip2.begin();
    pc.printf("LED strip alive!\r\n");
    // Update the strip, to start they are all 'off'
    strip.show();
    strip2.show();
    pc.printf("LED strip initialised!\r\n");

    //wifly.reset();

    //Init thread list
    for (unsigned int i = 0; i < THREADMAX; ++i)
        threadlist[i] = NULL;

    TCPSocketServer server;
    server.set_blocking(false);
    server.bind(80);

    server.listen();

    pc.printf("Accepting connections!\r\n");

    client.set_blocking(false);
    while (server.accept(client));


    Thread t(listen, (void*)NULL);
    Thread::wait(osWaitForever);
}
